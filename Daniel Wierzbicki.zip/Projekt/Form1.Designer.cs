﻿namespace Projekt
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otwórzToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zapiszToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zapiszJakoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obliczeniaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.energiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kinetycznaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potencjalnaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ruchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prędkośćToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drogaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.czasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quiz = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.Ep = new System.Windows.Forms.GroupBox();
            this.E = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.EnergiaKinetyczna = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.predkosc = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.save = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1.SuspendLayout();
            this.quiz.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.Ep.SuspendLayout();
            this.EnergiaKinetyczna.SuspendLayout();
            this.predkosc.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plikToolStripMenuItem,
            this.obliczeniaToolStripMenuItem,
            this.quizToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(774, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plikToolStripMenuItem
            // 
            this.plikToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.otwórzToolStripMenuItem,
            this.zapiszToolStripMenuItem,
            this.zapiszJakoToolStripMenuItem});
            this.plikToolStripMenuItem.Name = "plikToolStripMenuItem";
            this.plikToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.plikToolStripMenuItem.Text = "Plik";
            // 
            // otwórzToolStripMenuItem
            // 
            this.otwórzToolStripMenuItem.Name = "otwórzToolStripMenuItem";
            this.otwórzToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.otwórzToolStripMenuItem.Text = "Otwórz";
            // 
            // zapiszToolStripMenuItem
            // 
            this.zapiszToolStripMenuItem.Name = "zapiszToolStripMenuItem";
            this.zapiszToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.zapiszToolStripMenuItem.Text = "Zapisz";
            // 
            // zapiszJakoToolStripMenuItem
            // 
            this.zapiszJakoToolStripMenuItem.Name = "zapiszJakoToolStripMenuItem";
            this.zapiszJakoToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.zapiszJakoToolStripMenuItem.Text = "Zapisz jako";
            this.zapiszJakoToolStripMenuItem.Click += new System.EventHandler(this.zapiszJakoToolStripMenuItem_Click);
            // 
            // obliczeniaToolStripMenuItem
            // 
            this.obliczeniaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.energiaToolStripMenuItem,
            this.ruchToolStripMenuItem});
            this.obliczeniaToolStripMenuItem.Name = "obliczeniaToolStripMenuItem";
            this.obliczeniaToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.obliczeniaToolStripMenuItem.Text = "Obliczenia";
            // 
            // energiaToolStripMenuItem
            // 
            this.energiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kinetycznaToolStripMenuItem,
            this.potencjalnaToolStripMenuItem});
            this.energiaToolStripMenuItem.Name = "energiaToolStripMenuItem";
            this.energiaToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.energiaToolStripMenuItem.Text = "Energia";
            // 
            // kinetycznaToolStripMenuItem
            // 
            this.kinetycznaToolStripMenuItem.Name = "kinetycznaToolStripMenuItem";
            this.kinetycznaToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.kinetycznaToolStripMenuItem.Text = "Kinetyczna";
            this.kinetycznaToolStripMenuItem.Click += new System.EventHandler(this.kinetycznaToolStripMenuItem_Click);
            // 
            // potencjalnaToolStripMenuItem
            // 
            this.potencjalnaToolStripMenuItem.Name = "potencjalnaToolStripMenuItem";
            this.potencjalnaToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.potencjalnaToolStripMenuItem.Text = "Potencjalna";
            this.potencjalnaToolStripMenuItem.Click += new System.EventHandler(this.potencjalnaToolStripMenuItem_Click);
            // 
            // ruchToolStripMenuItem
            // 
            this.ruchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prędkośćToolStripMenuItem,
            this.drogaToolStripMenuItem,
            this.czasToolStripMenuItem});
            this.ruchToolStripMenuItem.Name = "ruchToolStripMenuItem";
            this.ruchToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ruchToolStripMenuItem.Text = "Ruch";
            this.ruchToolStripMenuItem.Click += new System.EventHandler(this.ruchToolStripMenuItem_Click);
            // 
            // prędkośćToolStripMenuItem
            // 
            this.prędkośćToolStripMenuItem.Name = "prędkośćToolStripMenuItem";
            this.prędkośćToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.prędkośćToolStripMenuItem.Text = "Prędkość";
            this.prędkośćToolStripMenuItem.Click += new System.EventHandler(this.prędkośćToolStripMenuItem_Click);
            // 
            // drogaToolStripMenuItem
            // 
            this.drogaToolStripMenuItem.Name = "drogaToolStripMenuItem";
            this.drogaToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.drogaToolStripMenuItem.Text = "Droga";
            this.drogaToolStripMenuItem.Click += new System.EventHandler(this.drogaToolStripMenuItem_Click);
            // 
            // czasToolStripMenuItem
            // 
            this.czasToolStripMenuItem.Name = "czasToolStripMenuItem";
            this.czasToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.czasToolStripMenuItem.Text = "Czas";
            this.czasToolStripMenuItem.Click += new System.EventHandler(this.czasToolStripMenuItem_Click_1);
            // 
            // quizToolStripMenuItem
            // 
            this.quizToolStripMenuItem.Name = "quizToolStripMenuItem";
            this.quizToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.quizToolStripMenuItem.Text = "Quiz";
            this.quizToolStripMenuItem.Click += new System.EventHandler(this.quizToolStripMenuItem_Click);
            // 
            // quiz
            // 
            this.quiz.Controls.Add(this.groupBox3);
            this.quiz.Controls.Add(this.groupBox5);
            this.quiz.Controls.Add(this.button4);
            this.quiz.Controls.Add(this.textBox7);
            this.quiz.Controls.Add(this.label14);
            this.quiz.Controls.Add(this.checkedListBox1);
            this.quiz.Controls.Add(this.label13);
            this.quiz.Controls.Add(this.listBox1);
            this.quiz.Controls.Add(this.label12);
            this.quiz.Controls.Add(this.radioButton3);
            this.quiz.Controls.Add(this.radioButton4);
            this.quiz.Controls.Add(this.label10);
            this.quiz.Location = new System.Drawing.Point(7, 27);
            this.quiz.Name = "quiz";
            this.quiz.Size = new System.Drawing.Size(767, 419);
            this.quiz.TabIndex = 1;
            this.quiz.TabStop = false;
            this.quiz.Text = "Quiz";
            this.quiz.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(16, 41);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(735, 36);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(634, 13);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(46, 17);
            this.radioButton1.TabIndex = 1;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "TAK";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(686, 13);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(43, 17);
            this.radioButton2.TabIndex = 2;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "NIE";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(336, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Czy energia mechaniczna jest sumą energii kinetycznej i potencjalnej?";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.radioButton6);
            this.groupBox5.Controls.Add(this.radioButton5);
            this.groupBox5.Location = new System.Drawing.Point(16, 83);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(735, 35);
            this.groupBox5.TabIndex = 28;
            this.groupBox5.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(480, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Czy energia mechaniczna może zostać całkowicie zamieniona na energię cieplną w pr" +
    "ocesie tarcia?";
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(634, 11);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(46, 17);
            this.radioButton6.TabIndex = 7;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "TAK";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(686, 11);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(43, 17);
            this.radioButton5.TabIndex = 8;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "NIE";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(283, 383);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 26;
            this.button4.Text = "Zatwierdź";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(142, 383);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 25;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(83, 386);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 24;
            this.label14.Text = "Nazwisko";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Energia mechaniczna zależy tylko od prędkości obiektu",
            "Energia mechaniczna może obejmować zarówno energię kinetyczną, jak i potencjalną",
            "Energia mechaniczna jest zawsze równa zeru",
            "W układzie zamkniętym energia mechaniczna jest stała, jeśli nie działają siły zew" +
                "nętrzne"});
            this.checkedListBox1.Location = new System.Drawing.Point(31, 274);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(456, 64);
            this.checkedListBox1.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 241);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(524, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "Które z poniższych stwierdzeń jest prawdziwe w kontekście energii mechanicznej? (" +
    "Wybierz jedną odpowiedź)";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "Gram",
            "Kilogram",
            "Tona"});
            this.listBox1.Location = new System.Drawing.Point(34, 143);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 21;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 127);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(230, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "Podstawowa jednostka masy w układzie SI to?";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(702, 13);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(43, 17);
            this.radioButton3.TabIndex = 19;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "NIE";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(650, 14);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(46, 17);
            this.radioButton4.TabIndex = 18;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "TAK";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(559, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Czy energia mechaniczna w układzie zamkniętym pozostaje niezmieniona, jeśli nie d" +
    "ziałają na niego siły zewnętrzne?";
            // 
            // Ep
            // 
            this.Ep.Controls.Add(this.E);
            this.Ep.Controls.Add(this.button1);
            this.Ep.Controls.Add(this.textBox2);
            this.Ep.Controls.Add(this.textBox1);
            this.Ep.Controls.Add(this.label2);
            this.Ep.Controls.Add(this.label1);
            this.Ep.Location = new System.Drawing.Point(12, 40);
            this.Ep.Name = "Ep";
            this.Ep.Size = new System.Drawing.Size(230, 325);
            this.Ep.TabIndex = 0;
            this.Ep.TabStop = false;
            this.Ep.Text = "Energia Potencjalna";
            // 
            // E
            // 
            this.E.AutoSize = true;
            this.E.Location = new System.Drawing.Point(21, 168);
            this.E.Name = "E";
            this.E.Size = new System.Drawing.Size(26, 13);
            this.E.TabIndex = 5;
            this.E.Text = "E = ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(73, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Oblicz";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(116, 57);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(116, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Wysokość[m]";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Masa[kg]";
            // 
            // EnergiaKinetyczna
            // 
            this.EnergiaKinetyczna.Controls.Add(this.label3);
            this.EnergiaKinetyczna.Controls.Add(this.button2);
            this.EnergiaKinetyczna.Controls.Add(this.textBox3);
            this.EnergiaKinetyczna.Controls.Add(this.textBox4);
            this.EnergiaKinetyczna.Controls.Add(this.label4);
            this.EnergiaKinetyczna.Controls.Add(this.label5);
            this.EnergiaKinetyczna.Location = new System.Drawing.Point(248, 40);
            this.EnergiaKinetyczna.Name = "EnergiaKinetyczna";
            this.EnergiaKinetyczna.Size = new System.Drawing.Size(230, 325);
            this.EnergiaKinetyczna.TabIndex = 0;
            this.EnergiaKinetyczna.TabStop = false;
            this.EnergiaKinetyczna.Text = "Energia Kinetyczna";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "E = ";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(73, 114);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Oblicz";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(116, 57);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(116, 30);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Prędkość[m/s]";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Masa[kg]";
            // 
            // predkosc
            // 
            this.predkosc.Controls.Add(this.label6);
            this.predkosc.Controls.Add(this.button3);
            this.predkosc.Controls.Add(this.textBox5);
            this.predkosc.Controls.Add(this.textBox6);
            this.predkosc.Controls.Add(this.label7);
            this.predkosc.Controls.Add(this.label8);
            this.predkosc.Location = new System.Drawing.Point(484, 49);
            this.predkosc.Name = "predkosc";
            this.predkosc.Size = new System.Drawing.Size(200, 316);
            this.predkosc.TabIndex = 2;
            this.predkosc.TabStop = false;
            this.predkosc.Text = "Prędkość";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "V = ";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(61, 104);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 10;
            this.button3.Text = "Oblicz";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(104, 47);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 9;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(104, 20);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Czas[s]";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Droga[m]";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 450);
            this.Controls.Add(this.predkosc);
            this.Controls.Add(this.EnergiaKinetyczna);
            this.Controls.Add(this.quiz);
            this.Controls.Add(this.Ep);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.quiz.ResumeLayout(false);
            this.quiz.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.Ep.ResumeLayout(false);
            this.Ep.PerformLayout();
            this.EnergiaKinetyczna.ResumeLayout(false);
            this.EnergiaKinetyczna.PerformLayout();
            this.predkosc.ResumeLayout(false);
            this.predkosc.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otwórzToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zapiszToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zapiszJakoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obliczeniaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem energiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kinetycznaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potencjalnaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ruchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prędkośćToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drogaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem czasToolStripMenuItem;
        private System.Windows.Forms.GroupBox quiz;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox EnergiaKinetyczna;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox Ep;
        private System.Windows.Forms.Label E;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox predkosc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.SaveFileDialog save;
    }
}

