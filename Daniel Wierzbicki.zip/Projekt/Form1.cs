﻿using System;
using System.IO;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Projekt
{
    public partial class Form1: Form
    {
        int data;
        public Form1()
        {
            InitializeComponent();
            EnergiaKinetyczna.Visible = false;
            Ep.Visible = false;
            quiz.Visible = false;
            predkosc.Visible = false;
            button2.Click += (sender, e) =>
            {
                label3.Text += (0.5 * float.Parse(textBox4.Text) * Math.Pow(float.Parse(textBox3.Text), 2)) + "J";
                data = 1;
            };
            button1.Click += (sender, e) =>
            {
                Ep.Visible = true;
                E.Text += (float.Parse(textBox1.Text) * float.Parse(textBox2.Text) * 9.81);
                data = 2;
            };
            button4.Click += (sender, e) => {
                int wynik = 0;
                if (radioButton1.Checked) wynik++;
                if (radioButton4.Checked) wynik++;
                if (radioButton6.Checked) wynik++;
                if (listBox1.SelectedItem.ToString() == "Kilogram")
                {
                    wynik++;

                }
                if (checkedListBox1.GetItemChecked(1))
                {
                    wynik++;
                    MessageBox.Show(checkedListBox1.SelectedItem.ToString());
                }
                MessageBox.Show($"Wynik = {wynik}");
            };
        }

        private void ruchToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void kinetycznaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnergiaKinetyczna.Visible = true;
            Ep.Visible = false;
            predkosc.Visible = false;
        }

        private void potencjalnaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ep.Visible = true;
            EnergiaKinetyczna.Visible = false;
            predkosc.Visible = false;
        }

        private void prędkośćToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label8.Text = "Droga[m]";
            label7.Text = "Czas[s]";
            predkosc.Text = "Prędkośc";
            label6.Text = "v=";
            predkosc.Visible = true;
            button3.Click += velocity;
            data = 3;
        }
        private void czasToolStripMenuItem_Click(object sender, EventArgs e)
        {

            label8.Text = "Droga[m]";
            label7.Text = "Prędkość[m/s]";
            label6.Text = "t=";
            predkosc.Visible = true;
            button3.Click += time;
            predkosc.Text = "Czas";
            data = 3;
        }
        private void drogaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            predkosc.Visible = true;
            label8.Text = "Prędkość[m/s]";
            label7.Text = "Czas[s]";
            label6.Text = "s=";
            button3.Click += distance;
            predkosc.Text = "Droga";
            data = 3;
        }
        private void time(object sender, EventArgs e)
        {
            label6.Text += (float.Parse(textBox6.Text) / float.Parse(textBox5.Text)) + "s";
        }
        private void velocity(object sender, EventArgs e)
        {
            label6.Text += (float.Parse(textBox6.Text) / float.Parse(textBox5.Text)) + "m/s";
        }
        private void distance(object sender, EventArgs e)
        { 
            label6.Text += (float.Parse(textBox6.Text) * float.Parse(textBox5.Text)) + "m";
        }

        private void zapiszJakoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (save.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter writer = new StreamWriter(save.FileName))
                {
                    if (data == 1) writer.WriteLine($"[{DateTime.Now}] {label5.Text} {textBox4.Text} | {label4.Text} {textBox3.Text} | {label3.Text}");
                    if (data == 2) writer.WriteLine($"[{DateTime.Now}] {label5.Text} {textBox4.Text} | {label4.Text} {textBox3.Text} | {label3.Text}");
                    if (data == 3) writer.WriteLine($"[{DateTime.Now}] {label1.Text} {textBox1.Text} | {label2.Text} {textBox2.Text} | {E.Text}");
                }
            }
        }

        private void quizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            quiz.Visible = true;
            Ep.Visible = false;
            EnergiaKinetyczna.Visible = false;
        }

        private void czasToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            label8.Text = "Droga[m]";
            label7.Text = "Prędkość[m/s]";
            label6.Text = "t=";
            predkosc.Visible = true;
            button3.Click += time;
            predkosc.Text = "Czas";
            data = 3;
        }
    }
}
